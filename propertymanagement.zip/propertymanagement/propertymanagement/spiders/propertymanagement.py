from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import PropertymanagementItem


class PropertymanagementSpider(CrawlSpider):

    name = "propertymanagement"

    def __init__(self, config_file = None, *args, **kwargs):                    
        super(PropertymanagementSpider, self).__init__(*args, **kwargs)   

        self.links = []

        with open('input.txt') as f:
            
            for link in f.readlines():
                link = link.strip("\n")
                print(link)
                self.links.append(link)

    def start_requests(self):    

        for link in self.links:            
            yield Request(url = link, callback = self.parse)

    def parse(self, response):        

        for box in response.css(".white-box"):

            items = PropertymanagementItem()

            items["name"] = box.css(".part-two h3::text").extract_first()
            
            items["number"] = box.css(".telephone::attr(href)").extract_first()

            items["website"] = box.css(".website::attr(href)").extract_first()

            yield items

 